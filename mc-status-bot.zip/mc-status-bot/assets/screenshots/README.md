# Screenshots

Place real screenshots of the running Discord bot here:

- `java-status.png`
- `bedrock-status.png`
- `auto-update.png`
- `setup-status.png`

Then commit the images and they will automatically appear in the main README.
